﻿using System.Threading.Tasks;
using Firebase;
using Firebase.Auth;
using Firebase.Extensions;
using UnityEngine;

public class BackendManager : MonoBehaviour
{
    public static BackendManager Instance { get; private set; }

    private FirebaseApp _app;
    public static FirebaseApp App => Instance._app;

    private FirebaseAuth _auth;
    public static FirebaseAuth Auth => Instance._auth;

    // Firebase 초기화 완료 + 성공 여부를 await 가능하도록 노출  
    // 자동로그인 흐름 시작 전에 'await BackendManager.ReadyTask'  
    private static readonly TaskCompletionSource<bool> _readyTcs = new();
    public static Task<bool> ReadyTask => _readyTcs.Task;

    private void Awake()
    {
        SetSingleton();
        CheckAndFixDependencies();
    }

    private void CheckAndFixDependencies()
    {
        FirebaseApp.CheckAndFixDependenciesAsync().ContinueWithOnMainThread(task =>
        {
            bool isAvailable = task.Result == DependencyStatus.Available;

            if (isAvailable)
            {
                _app = FirebaseApp.DefaultInstance;
                _auth = FirebaseAuth.DefaultInstance;
            }
            else
            {
                Debug.LogError($"BackendManager : {task.Result}");
                _app = null;
                _auth = null;
            }

            _readyTcs.TrySetResult(isAvailable);
        });
    }

    private void SetSingleton()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
}
